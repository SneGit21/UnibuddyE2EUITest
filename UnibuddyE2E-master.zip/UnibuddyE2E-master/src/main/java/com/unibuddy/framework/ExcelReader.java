package com.unibuddy.framework;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	/**
	 * @param filePath  excel file path
	 * @param sheetName  sheet name in xlsx file
	 * @return excel data
	 * @throws InvalidFormatException
	 * @throws IOException
	 */
	public static String[][] TestData;
	public static XSSFSheet Sheet;
	public static XSSFWorkbook WBook = null;
	public static XSSFSheet WSheet = null;
	public static XSSFRow Row;
	public static XSSFCell cell;
	public static Object[][] readExcel(String filePath, String sheetName) throws InvalidFormatException, IOException {
		FileInputStream file= new FileInputStream(filePath);
		@SuppressWarnings("resource")
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet(sheetName);
		int rowCount = sheet.getLastRowNum();
		//(sheet.getLastRowNum() - sheet.getFirstRowNum()) + 1;
		//sheet.getLastRowNum();
		int column = sheet.getRow(0).getLastCellNum();
		Object[][] data = new Object[rowCount][column];
		for (int i = 1; i <= rowCount; i++) {
			XSSFRow row = sheet.getRow(i);
			for (int j = 0; j < column; j++) {
				XSSFCell cell = row.getCell(j);
				DataFormatter formatter = new DataFormatter();
				String val = formatter.formatCellValue(cell);
				data[i - 1][j] = val;
			}
		}
		return data;
	}

	public static void writeToCell(String FilePath,String executionStatus, String SheetName, int rowNum, int colNum)
	{		try
	{
		FileInputStream fis = new FileInputStream(FilePath);
		@SuppressWarnings("unused")
		Workbook wb = WorkbookFactory.create(fis);
		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		org.apache.poi.ss.usermodel.Sheet sh = workbook.getSheet(SheetName);
		Row  row = sh.getRow(rowNum);
		Cell cell = row.createCell(colNum);
		//cell.setCellType(cell.CELL_TYPE_STRING);
		cell.setCellValue(executionStatus);
		FileOutputStream fos = new FileOutputStream(FilePath);
		workbook.write(fos);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
	public static XSSFSheet DataSheet(String FilePath, String SheetName)
	{
		File file = new File(FilePath);
		try{
			FileInputStream fis = new FileInputStream(file);
			WBook = new XSSFWorkbook(fis);
			WSheet = WBook.getSheet(SheetName);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return WSheet;
	}
	public static int rowCount(String FilePath,String SheetName)
	{
		XSSFSheet sheet;
		sheet = DataSheet(FilePath, SheetName);
		int rowCount = (sheet.getLastRowNum() - sheet.getFirstRowNum())+1;
		return rowCount;
	}

	public static int colCount(String FilePath,String SheetName)
	{
		XSSFSheet sheet;
		sheet = DataSheet(FilePath, SheetName);
		@SuppressWarnings("rawtypes")
		Iterator rowIterator = sheet.rowIterator();
		int collumnCount = 0;
		if(rowIterator.hasNext())
		{
			org.apache.poi.ss.usermodel.Row headerRow =(org.apache.poi.ss.usermodel.Row) rowIterator.next();
			collumnCount = headerRow.getPhysicalNumberOfCells();
		}
		return collumnCount;
	}

}

