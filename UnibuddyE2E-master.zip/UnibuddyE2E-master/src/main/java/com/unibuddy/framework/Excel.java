//package com.unibuddy.framework;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.util.Iterator;
//
//import org.apache.poi.openxml4j.exceptions.*;
//
//import org.apache.poi.xssf.usermodel.XSSFCell;
//import org.apache.poi.xssf.usermodel.XSSFRow;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.apache.poi.xssf.usermodel.XSSFWorkbookFactory;
////import freemarker.template.utility.DateUtil;
//import org.apache.poi.ss.usermodel.DateUtil;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.util.WorkbookUtil;
//public class Excel {
//	public static String[][] TestData;
//	public static XSSFSheet Sheet;
//	public static XSSFWorkbook WBook = null;
//	public static XSSFSheet WSheet = null;
//	public static XSSFRow Row;
//	public static XSSFCell cell;
//	public static String FilePath = System.getProperty("user.dir")+"\\src\\main\\resources\\TestData\\TestData.xlsx";
//	public static XSSFSheet DataSheet(String FilePath, String SheetName)
//	{
//		File file = new File(FilePath);
//		try{
//			FileInputStream fis = new FileInputStream(file);
//			WBook = new XSSFWorkbook(fis);
//			WSheet = WBook.getSheet(SheetName);
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//		return WSheet;
//	}
//	
//	public static String[][] getTestData(String SheetName)
//	{
//		Sheet = DataSheet(FilePath, SheetName);
//		int rowCount = (Sheet.getLastRowNum() - Sheet.getFirstRowNum()) + 1;
//		int colCount = Sheet.getRow(0).getLastCellNum();
//		TestData = new String[rowCount][colCount];
//		for(int rCnt=0; rCnt<colCount; rCnt++)
//		{
//			for(int cCnt=0; cCnt<colCount; cCnt++)
//			{
//				TestData[rCnt][cCnt] = getCellData(SheetName, rCnt, cCnt);
//			}
//		}
//		return TestData;
//	}
//	
//	public static String getCellData(String SheetName, int row, int col)
//	{
//		try{
//			int index = WBook.getSheetIndex(SheetName);
//			WSheet = WBook.getSheetAt(index);
//			Row = WSheet.getRow(row);
//			if(Row == null)
//			return "";
//			
//			cell = Row.getCell(col);
//			if(cell == null)
//				return "";
//			
//			switch(cell.getCellType())
//			{
//			case Cell.CELL_TYPE_STRING: return cell.getStringCellValue();
//			case Cell.CELL_TYPE_BOOLEAN : return String.valueOf(cell.getDateCellValue());
//			case Cell.CELL_TYPE_BLANK: return "";
//			case Cell.CELL_TYPE_ERROR: return cell.getStringCellValue();
//			case Cell.CELL_TYPE_NUMERIC: 
//			if(DateUtil.isCellDateFormatted(cell)){
//				return String.valueOf(cell.getDateCellValue());
//			}else{
//				return String.valueOf(cell.getNumericCellValue());
//			}
//			default: return "Cell Not Found";
//			}
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//			return "row "+row+" or column "+col+" does not exist in xls";
//		}
//	}
//	
//	public int rowCount(String SheetName)
//	{
//		XSSFSheet sheet;
//		Sheet = DataSheet(FilePath, SheetName);
//		int rowCount = (Sheet.getLastRowNum() - Sheet.getFirstRowNum())+1;
//		return rowCount;
//	}
//	
//	public int colCount(String SheetName)
//	{
//		XSSFSheet sheet;
//		Sheet = DataSheet(FilePath, SheetName);
//		Iterator rowIterator = Sheet.rowIterator();
//		int collumnCount = 0;
//		if(rowIterator.hasNext())
//		{
//			org.apache.poi.ss.usermodel.Row headerRow =(org.apache.poi.ss.usermodel.Row) rowIterator.next();
//			collumnCount = headerRow.getPhysicalNumberOfCells();
//		}
//		return collumnCount;
//	}
//	
//	public void writeToCell(String executionStatus, String SheetName, int rowNum, int colNum)
//	{
//		try
//		{
//			FileInputStream fis = new FileInputStream(FilePath);
////			Workbook wb = WorkbookUtil.createSafeSheetName(fis);//.create(fis);
////			Workbook wb = XSSFWorkbookFactory.create(fis);
//			XSSFWorkbook workbook = new XSSFWorkbook(fis);
//			org.apache.poi.ss.usermodel.Sheet sh = workbook.getSheet(SheetName);
//			Row  row = sh.getRow(rowNum);
//			Cell cell = row.createCell(colNum);
//			cell.setCellType(cell.CELL_TYPE_STRING);
//			cell.setCellValue(executionStatus);
//			FileOutputStream fos = new FileOutputStream(FilePath);
//			workbook.write(fos);
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//	}
//}
