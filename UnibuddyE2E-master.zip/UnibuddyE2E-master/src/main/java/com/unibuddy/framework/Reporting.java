package com.unibuddy.framework;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Reporting {
	public static ExtentReports extent;
	public static ExtentTest test;
	public static String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
	public static String getScreenshot(WebDriver driver, String screenshotName) throws IOException
	{
		//String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = System.getProperty("user.dir") + "/test-output/"+screenshotName+dateName+".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		@SuppressWarnings("unused")
		String screenshotsPath = "./test-output" + finalDestination.getName();
		return destination;

	}
}
