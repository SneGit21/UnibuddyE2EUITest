package com.unibuddy.test;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.mail.EmailException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.unibuddy.framework.BrowserFactory;
import com.unibuddy.framework.Reporting;
public class HelperClass {
 
public static WebDriver driver;
BrowserFactory obj1;

//String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
public HelperClass(){
}
 
@BeforeSuite
public void beforeSuite(){
	HelperClass.driver = BrowserFactory.getDriver("chrome");
	BrowserFactory.getDriver().get("https://events-staging.unibuddy.co/your-university/my-first-event/");
	
	//Setting the Report Name for Starting the Report
	Reporting.extent = new ExtentReports(System.getProperty("user.dir") + "\\test-output\\AutomationTestReport"+
			Reporting.dateName+".html");
	
	//Loading the Report Configuration from extent-config.xml file
	Reporting.extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
	
	//To display environment details in report
	Reporting.extent.addSystemInfo("Browser Name", "chrome");
	
}
 
@BeforeClass
public void beforeClass(){
System.out.println("in @BeforeClass");
}
 
@BeforeMethod
public void beforeMethodClass(){
System.out.println("in @BeforeMethod");
//HelperClass.driver = BrowserFactory.getDriver("chrome");
 
}
 
@AfterMethod
public void getResult(ITestResult result, ITestContext c) throws IOException
{
 String[] finalError = null;
 String[] output = null;
 String[] s = null;
 String screenshotPath = null;
 if(result.getStatus() == ITestResult.FAILURE)
 {
	 try{
		 String exception = result.getThrowable().toString();
		 String subException = exception.trim();
		 output = subException.split("\\{");
		 s = output[1].split("\\}");
		 finalError = subException.split(":");
		 Reporting.test.log(LogStatus.FAIL, finalError[2]+" "+s[0]);
		 screenshotPath = Reporting.getScreenshot(BrowserFactory.getDriver(), result.getName());
		 Reporting.test.log(LogStatus.FAIL, "Test Case "+result.getName()+" is FAILED");
		 Reporting.test.log(LogStatus.FAIL, Reporting.test.addScreenCapture(screenshotPath));
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
 }
 else if(result.getStatus() == ITestResult.SUCCESS){
	 try{
	 Reporting.test.log(LogStatus.PASS, "Test Case "+result.getName()+" is PASSED");
	 screenshotPath = Reporting.getScreenshot(BrowserFactory.getDriver(), result.getName());
	 Reporting.test.log(LogStatus.PASS, Reporting.test.addScreenCapture(screenshotPath));
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
 }
 else if(result.getStatus() == ITestResult.SKIP){
	 try{
	 Reporting.test.log(LogStatus.SKIP, "Test Case "+result.getName()+" is SKIPPED");
	 screenshotPath = Reporting.getScreenshot(BrowserFactory.getDriver(), result.getName());
	 Reporting.test.log(LogStatus.SKIP, Reporting.test.addScreenCapture(screenshotPath));
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
 }
//this.driver.close();
}
 
@AfterClass
public void afterClass(){
 
}
 
@AfterSuite
public void afterSuite() throws IOException, EmailException{
 //To end the extent test report
	Reporting.extent.endTest(Reporting.test);

 //To delete or flush off the extent report object
	Reporting.extent.flush();
	
 //Tp display the extent report in the browser after the test execution
	BrowserFactory.getDriver().get(System.getProperty("user.dir")+"\\test-output\\AutomationTestReport"+
			Reporting.dateName+".html");
//driver.quit();
}
}
