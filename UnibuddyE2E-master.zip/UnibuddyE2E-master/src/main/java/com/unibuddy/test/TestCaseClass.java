package com.unibuddy.test;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.unibuddy.framework.*;
import com.unibuddy.ui.*;
 
public class TestCaseClass extends HelperClass {

public TestCaseClass(){
}

//@BeforeTest()
//public void NavigateToApplicationURL(){
//driver.get("https://events-staging.unibuddy.co/your-university/my-first-event/");
//}
//@Test
public void returnTicket() {
try {
System.out.println("in returnTicket");
//driver.get("<a href="http://newtours.demoaut.com/">http://newtours.demoaut.com/</a>");
driver.get("http://newtours.demoaut.com/");
Login loginPage = PageFactory.initElements(driver, Login.class);
loginPage.loginWordPress("mercury", "mercury");
FlightFinderPage flightFinderpage = PageFactory.initElements(driver, FlightFinderPage.class);
flightFinderpage.continueWordPress("1","Zurich","July","12","Frankfurt","September","15","Business Class","Unified Airlines");
SelectFlightPage selectFlightPage = PageFactory.initElements(driver, SelectFlightPage.class);
selectFlightPage.departAirlineWordPress("Pangaea Airlines 362");
selectFlightPage.returnAirlineWordPress("Unified Airlines 363");
selectFlightPage.continu();
BookFlightPage bookFlightPage = PageFactory.initElements(driver, BookFlightPage.class);
bookFlightPage.purchasePress("Anirudh", "AS", "Vegetarian", "MasterCard", "12345678", "12", "2008", "Anirudh", "A", "S");
FlightConfirmationPage flightConfirmationPage = PageFactory.initElements(driver, FlightConfirmationPage.class);
String bookingDetailsFile = System.getProperty("user.dir")+"\\ScreenShotsFlightConfirmationDetails\\"+CaptureScreenShot.getDateTimeStamp()+".png";
try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), bookingDetailsFile);
} catch (Exception e) {e.printStackTrace();}
 
flightConfirmationPage.logoutPress();
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
 
}


@Test(priority=1)
public void SignUp() {
try {
System.out.println("in SignUp Method of Test Class");
//Starting the test and logging it in the report
Reporting.test = Reporting.extent.startTest("Sign up", "Signing up to Unibuddy testing events page");
	
SignUpPage signupPage = PageFactory.initElements(driver, SignUpPage.class);
String FirstName = BrowserFactory.generateRandomString(4)+"Test123";
String LastName = "Unibuddy";
String EmailAddress = BrowserFactory.generateRandomString(4)+"test123@unibudy.com";
String Password = BrowserFactory.generateRandomString(4)+"@123";
String JoiningDate = "2020-09";
String Country = "India";
String Degree = "a";
String FavCheese =  "Test";
signupPage.signUp(FirstName, LastName, EmailAddress, Password, JoiningDate, Country, Degree,FavCheese);
String SignUpDetailsFile = System.getProperty("user.dir")+"\\ScreenShotsUnibuddySignUp\\"+CaptureScreenShot.getDateTimeStamp()+".png";
try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), SignUpDetailsFile);
} catch (Exception e) {e.printStackTrace();}
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}
//
//
//@Test(priority=2)
//public void LogOut() {
//try {
//System.out.println("in SignUp Method of Test Class");
//Logout logOut = PageFactory.initElements(driver, Logout.class);
//logOut.logout();
//String logOutDetailsFile = System.getProperty("user.dir")+"\\ScreenShotsUnibuddyEvents\\"+CaptureScreenShot.getDateTimeStamp()+".png";
//try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), logOutDetailsFile);
//} catch (Exception e) {e.printStackTrace();}
//
//} catch (Exception e) {
//// TODO Auto-generated catch block
//e.printStackTrace();
//}
//}
//
//@Test(priority=3)
//public void Login() {
//try {
//System.out.println("in SignUp Method of Test Class");
//SignUpPage signupPage = PageFactory.initElements(driver, SignUpPage.class);
//signupPage.signUp();
//String eventDetailsFile = System.getProperty("user.dir")+"\\ScreenShotsUnibuddyEvents\\"+CaptureScreenShot.getDateTimeStamp()+".png";
//try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), eventDetailsFile);
//} catch (Exception e) {e.printStackTrace();}
//
//} catch (Exception e) {
//// TODO Auto-generated catch block
//e.printStackTrace();
//}
//}
//
//@Test(priority=4)
//public void SelectFeed() {
//try {
//System.out.println("in SignUp Method of Test Class");
//SignUpPage signupPage = PageFactory.initElements(driver, SignUpPage.class);
//signupPage.signUp();
//String eventDetailsFile = System.getProperty("user.dir")+"\\ScreenShotsUnibuddyEvents\\"+CaptureScreenShot.getDateTimeStamp()+".png";
//try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), eventDetailsFile);
//} catch (Exception e) {e.printStackTrace();}
//
//} catch (Exception e) {
//// TODO Auto-generated catch block
//e.printStackTrace();
//}
//}
//
//@Test(priority=4)
//public void DirectMessages() {
//try {
//System.out.println("in SignUp Method of Test Class");
//SignUpPage signupPage = PageFactory.initElements(driver, SignUpPage.class);
//signupPage.signUp();
//String eventDetailsFile = System.getProperty("user.dir")+"\\ScreenShotsUnibuddyEvents\\"+CaptureScreenShot.getDateTimeStamp()+".png";
//try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), eventDetailsFile);
//} catch (Exception e) {e.printStackTrace();}
//
//} catch (Exception e) {
//// TODO Auto-generated catch block
//e.printStackTrace();
//}
//}


}