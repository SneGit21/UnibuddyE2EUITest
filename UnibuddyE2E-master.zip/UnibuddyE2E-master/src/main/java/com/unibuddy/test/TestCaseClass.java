package com.unibuddy.test;

import org.testng.annotations.Test;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import com.relevantcodes.extentreports.LogStatus;
import com.unibuddy.framework.*;
import com.unibuddy.ui.*;

public class TestCaseClass extends HelperClass {
	private String filePath = System.getProperty("user.dir")+"\\testdata\\TestData.xlsx";
	private String sheetName ;
	String FirstName;
	String LastName;
	String EmailAddress;
	String Password;
	public TestCaseClass(){
	}

	@Test(priority=1,dataProvider = "SignUpData")
	public void SignUp(String isIncludedInExecution, String FName, String LName, String EmailID, String Pwd,
			String DOJ, String country, String degree, String favCheese,String ExecutionResult) {
		try {
			System.out.println("in SignUp Method of Test Class");

			SignUpPage signupPage = PageFactory.initElements(driver, SignUpPage.class);

			if(isIncludedInExecution.equalsIgnoreCase("Yes"))
			{
				//Starting the test and logging it in the report
				Reporting.test = Reporting.extent.startTest("Sign up", "Signing up to Unibuddy testing events page");
				FirstName = BrowserFactory.generateRandomString(4)+FName;
				LastName = LName;
				EmailAddress = BrowserFactory.generateRandomString(4)+EmailID;
				Password = BrowserFactory.generateRandomString(4)+Pwd;
				String JoiningDate = DOJ;
				String Country = country;
				String Degree = degree;
				String FavCheese =  favCheese;
				boolean testResult ;
				testResult = signupPage.signUp(FirstName, LastName, EmailAddress, Password, JoiningDate, Country, Degree,FavCheese);
				String SignUpDetailsFile = System.getProperty("user.dir")+"\\ScreenShots\\ScreenShotsSignUp\\"+CaptureScreenShot.getDateTimeStamp()+".png";
				try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), SignUpDetailsFile);
				} catch (Exception e) {e.printStackTrace();}
				sheetName = "SignUpDetails";
				int rowNum = ExcelReader.rowCount(filePath, sheetName)-1;
				System.out.println("Row Count : "+rowNum);
				int colNum = ExcelReader.colCount(filePath, sheetName);
				System.out.println("Col Count : "+colNum);
				ExcelWriter objExcelFile = new ExcelWriter();
				if(testResult == true)
				{
					objExcelFile.writeExcel(System.getProperty("user.dir")+"\\testdata","TestData.xlsx","SignUpDetails","PASS",(rowNum-1), (colNum-1));
					Reporting.test.log(LogStatus.PASS, "Signed up to Unibuddy Events Successfully");
				}
				else
				{
					objExcelFile.writeExcel(System.getProperty("user.dir")+"\\testdata","TestData.xlsx","SignUpDetails","FAIL",(rowNum-1), (colNum-1));
					Reporting.test.log(LogStatus.FAIL, "Failed to Sign up to Unibuddy Events");
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@DataProvider(name="SignUpData")
	public Object[][] readExcelforSignUp() throws InvalidFormatException, IOException {
		sheetName = "SignUpDetails";
		return ExcelReader.readExcel(filePath, sheetName);
	}

	@Test(priority=2)
	public void LogOut() {
		try {
			System.out.println("in LogOut Method of Test Class");
			Reporting.test = Reporting.extent.startTest("Log Out", "Logging out from Unibuddy testing events page");
			Logout logOut = PageFactory.initElements(driver, Logout.class);
			boolean testResult = logOut.logout();
			String logOutDetailsFile = System.getProperty("user.dir")+"\\ScreenShots\\ScreenShotsLogout\\"+CaptureScreenShot.getDateTimeStamp()+".png";
			try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), logOutDetailsFile);
			} catch (Exception e) {e.printStackTrace();}
			if(testResult == true)
			{
				Reporting.test.log(LogStatus.PASS, "Logged out Successfully");
			}
			else
			{
				Reporting.test.log(LogStatus.FAIL, "Log out FAILED");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(priority=3)
	public void Login() {
		try {
			System.out.println("in Login Method of Test Class");
			Login login = PageFactory.initElements(driver, Login.class);
			Reporting.test = Reporting.extent.startTest("Login with Signed up user", "Logging in to Unibuddy testing events page");
			boolean testResult = login.login(FirstName, LastName, EmailAddress, Password);
			String eventDetailsFile = System.getProperty("user.dir")+"\\ScreenShots\\ScreenShotsLogin\\"+CaptureScreenShot.getDateTimeStamp()+".png";
			try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), eventDetailsFile);
			} catch (Exception e) {e.printStackTrace();}
			if(testResult == true)
			{
				Reporting.test.log(LogStatus.PASS, "Logged in Successfully");
			}
			else
			{
				Reporting.test.log(LogStatus.FAIL, "Login FAILED");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(priority=4,dataProvider = "FeedAndMessageData")
	public void SelectFeedAndSendMessage(String isIncludedInExecution, String feedName, String Message, String ExecutionResult) {
		try {
			System.out.println("in SelectFeedAndSendMessage Method of Test Class");
			SelectFeed selectFeed = PageFactory.initElements(driver, SelectFeed.class);
			if(isIncludedInExecution.equalsIgnoreCase("Yes"))
			{
				Reporting.test = Reporting.extent.startTest("Select Feed and Send Message", "Selecting feed and sending message to the chat");

				boolean testResult ;
				testResult = selectFeed.selectFeed(feedName, Message+BrowserFactory.generateRandomString(5));
				String eventDetailsFile = System.getProperty("user.dir")+"\\ScreenShots\\ScreenshotsSelectFeedAndSendMessage\\"+CaptureScreenShot.getDateTimeStamp()+".png";
				try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), eventDetailsFile);
				} catch (Exception e) {e.printStackTrace();}
				sheetName = "FeedAndMessage";
				int rowNum = ExcelReader.rowCount(filePath, sheetName)-1;
				System.out.println("Row Count : "+rowNum);
				int colNum = ExcelReader.colCount(filePath, sheetName);
				System.out.println("Col Count : "+colNum);
				ExcelWriter objExcelFile = new ExcelWriter();
				if(testResult == true)
				{
					objExcelFile.writeExcel(System.getProperty("user.dir")+"\\testdata","TestData.xlsx","FeedAndMessage","PASS",(rowNum-1), (colNum-1));
					Reporting.test.log(LogStatus.PASS, "Sent Message to Feed Successfully");
				}
				else
				{
					objExcelFile.writeExcel(System.getProperty("user.dir")+"\\testdata","TestData.xlsx","FeedAndMessage","FAIL",(rowNum-1), (colNum-1));
					Reporting.test.log(LogStatus.FAIL, "Sending Message to Feed FAILED");
				}
			} 
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@DataProvider(name="FeedAndMessageData")
	public Object[][] readExcelforFeed() throws InvalidFormatException, IOException {
		sheetName = "FeedAndMessage";
		return ExcelReader.readExcel(filePath, sheetName);
	}

	@Test(priority=5,dataProvider="DirectMessagesData")
	public void DirectMessages(String IsIncludedInExecution,String User, String Message, String ExecutionResult) {
		try {
			System.out.println("in DirectMessages Method of Test Class");
			DirectMessages directMsg = PageFactory.initElements(driver, DirectMessages.class);

			if(IsIncludedInExecution.equalsIgnoreCase("Yes"))
			{
				Reporting.test = Reporting.extent.startTest("Direct Messages", "Selecting user & sending message");
				boolean testResult ;
				testResult = directMsg.sendDirectMsgToUser(User, Message+BrowserFactory.generateRandomString(5));
				String eventDetailsFile = System.getProperty("user.dir")+"\\ScreenShots\\ScreenShotsDirectMessages\\"+CaptureScreenShot.getDateTimeStamp()+".png";
				try {CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(), eventDetailsFile);
				} catch (Exception e) {e.printStackTrace();}
				sheetName = "DirectMessages";
				int rowNum = ExcelReader.rowCount(filePath, sheetName)-1;
				System.out.println("Row Count : "+rowNum);
				int colNum = ExcelReader.colCount(filePath, sheetName);
				System.out.println("Col Count : "+colNum);
				ExcelWriter objExcelFile = new ExcelWriter();
				if(testResult == true)
				{
					objExcelFile.writeExcel(System.getProperty("user.dir")+"\\testdata","TestData.xlsx","DirectMessages","PASS",(rowNum-1), (colNum-1));
					Reporting.test.log(LogStatus.PASS, "Sent Direct Message to User Successfully");
				}
				else
				{
					objExcelFile.writeExcel(System.getProperty("user.dir")+"\\testdata","TestData.xlsx","DirectMessages","FAIL",(rowNum-1), (colNum-1));
					Reporting.test.log(LogStatus.FAIL, "Sending Direct Message to User FAILED");
				}	
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	@DataProvider(name="DirectMessagesData")
	public Object[][] readExcelforDirectMessages() throws InvalidFormatException, IOException {
		sheetName = "DirectMessages";
		return ExcelReader.readExcel(filePath, sheetName);
	}

}