package com.unibuddy.ui;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.unibuddy.framework.Reporting;

public class Logout {

	WebDriver driver;

	public Logout(WebDriver driver){
		this.driver=driver;
	}

	@FindBy(how=How.XPATH,using="//a[@aria-label='Logout']")
	@CacheLookup
	WebElement logOut;
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Log in')]")
	@CacheLookup
	WebElement verifyLogOut;

	public boolean logout() {
		try {
			logOut.click();
			Reporting.test.log(LogStatus.INFO, "Clicked on Logout button");
			Assert.assertEquals(true, verifyLogOut.isDisplayed());
			Reporting.test.log(LogStatus.PASS, "User Logged out successfully");
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

}
