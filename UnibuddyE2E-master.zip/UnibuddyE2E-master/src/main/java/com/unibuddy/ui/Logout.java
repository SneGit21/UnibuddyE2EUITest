package com.unibuddy.ui;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;
 
public class Logout {
 
WebDriver driver;
 
public Logout(WebDriver driver){
this.driver=driver;
}

@FindBy(how=How.XPATH,using="//a[@aria-label='Logout']")
@CacheLookup
WebElement logOut;
@FindBy(how=How.XPATH,using="//a[contains(text(),'Log in')]")
@CacheLookup
WebElement verifyLogOut;

public void logout() {
try {
	logOut.click();
	Assert.assertEquals(true, verifyLogOut.isDisplayed());
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}
 
}
