package com.unibuddy.ui;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.unibuddy.framework.BrowserFactory;
import com.unibuddy.framework.Reporting;
 
public class SignUpPage {
 
WebDriver driver;
public SignUpPage(WebDriver driver){
this.driver=driver;
}

@FindBy(how=How.LINK_TEXT,using="Sign up")
@CacheLookup
WebElement signup;
@FindBy(how=How.XPATH,using="//h1[@class='text-center']")
@CacheLookup
WebElement validateSignUp;
@FindBy(how=How.XPATH,using="//input[@id='first-name']")
@CacheLookup
WebElement firstName;
@FindBy(how=How.XPATH,using="//input[@id='last-name']")
@CacheLookup
WebElement lastName;
@FindBy(how=How.XPATH,using="//input[@id='email']")
@CacheLookup
WebElement email;
@FindBy(how=How.XPATH,using="//input[@id='password']")
@CacheLookup
WebElement password;
@FindBy(how=How.XPATH,using="//input[@id='confirm-password']")
@CacheLookup
WebElement confirmPassword;
@FindBy(how=How.ID,using="privacy")
@CacheLookup
WebElement AgreeCheckBox;
@FindBy(how=How.XPATH,using="//button[@id='continue']")
@CacheLookup
WebElement SignUpContinue;
@FindBy(how=How.XPATH,using="//h1[contains(text(),'Finally, a few last details')]")
@CacheLookup
WebElement FinallyFewSteps;
@FindBy(how=How.XPATH,using="//select[@id='dateOfEntry']//option[@value='")
@CacheLookup
WebElement joiningDate1;
@FindBy(how=How.XPATH,using="']")
@CacheLookup
WebElement joiningDate2;
//2020-09
@FindBy(how=How.XPATH,using="//input[@id='country']")
@CacheLookup
WebElement enterCountry;
@FindBy(how=How.XPATH,using="//a[@class='dropdown-item'][.='")
@CacheLookup
WebElement selectCountry1;
@FindBy(how=How.XPATH,using="']")
@CacheLookup
WebElement selectCountry2;
@FindBy(how=How.XPATH,using="//select[@id='degree-level']")
@CacheLookup
WebElement selectDegree;
@FindBy(how=How.XPATH,using="//input[@id='degrees']")
@CacheLookup
WebElement enterDegree;
@FindBy(how=How.XPATH,using="//button[contains(text(),'I don')]")
@CacheLookup
WebElement dontKnow;
@FindBy(how=How.XPATH,using="//button[contains(text(),'Add an area of study')]")
@CacheLookup
WebElement addAreaOfStudy;
@FindBy(how=How.XPATH,using="//input[@id='5ce664fe3245dc001c32eaed']")
@CacheLookup
WebElement faveCheese;
@FindBy(how=How.XPATH,using="//input[@id='marketing']")
@CacheLookup
WebElement agreeCheckboxMarketting;
@FindBy(how=How.XPATH,using="//span[contains(text(),'Continue')]")
@CacheLookup
WebElement continueBtn;
@FindBy(how=How.XPATH,using="//span[contains(text(),'My First Event')]")
@CacheLookup
WebElement myFirstEvent;
//@FindBy(how=How.XPATH,using="//a[@aria-label='Logout']")
//@CacheLookup
//WebElement logOut;
//@FindBy(how=How.XPATH,using="//div[text()='")
//@CacheLookup
//WebElement selectFeed1;
//@FindBy(how=How.XPATH,using="']")
//@CacheLookup
//WebElement selectFeed2;
//@FindBy(how=How.XPATH,using="//textarea[@id='chat-text-input']")
//@CacheLookup
//WebElement enterMessage;
//@FindBy(how=How.XPATH,using="//button[.='Send']")
//@CacheLookup
//WebElement sendMsg;
//@FindBy(how=How.XPATH,using="//div[contains(text(),'You said')]/../span/span")
//@CacheLookup
//WebElement verifySentMsg;
//@FindBy(how=How.XPATH,using="//button[contains(text(),'Direct Message')]//*[local-name()='svg']")
//@CacheLookup
//WebElement directMsg;
//@FindBy(how=How.XPATH,using="//p[contains(text(),'Select a buddy to begin a conversation.')]")
//@CacheLookup
//WebElement directMsgPopUp;
//@FindBy(how=How.XPATH,using="//a[1]//div[1]//div[1]//div[2]//div[1]//div[1]//span[1]//span[1]")
//@CacheLookup
//WebElement selectFirstUser;
//@FindBy(how=How.XPATH,using="//textarea[@id='chat-input']")
//@CacheLookup
//WebElement selectMsgToUser;
//@FindBy(how=How.XPATH,using="//span[contains(text(),'")
//@CacheLookup
//WebElement verifyMsgToUser1;
//@FindBy(how=How.XPATH,using="')]")
//@CacheLookup
//WebElement verifyMsgToUser2;
//@FindBy(how=How.XPATH,using="//a[contains(text(),'Log in')]")
//@CacheLookup
//WebElement verifyLogInBtn;
//@FindBy(how=How.XPATH,using="//h1[contains(text(),'Login')]")
//@CacheLookup
//WebElement verifyLoginScreen;
//@FindBy(how=How.XPATH,using="//button[@id='login']")
//@CacheLookup
//WebElement loginButton;
@FindBy(how=How.XPATH,using="//span[@class='sc-AxhCb eilNNX']//span")
@CacheLookup
WebElement verifyLoggedInUser;

public WebElement getJoiningDateLocator(String JoiningDate){
	String joiningDate = "//select[@id='dateOfEntry']//option[@value='"+JoiningDate+"']";
	WebElement joiningdate = driver.findElement(By.xpath(joiningDate));
	return joiningdate;
}

public WebElement getCountry(String country){
	String countri = "//a[@class='dropdown-item'][.='"+country+"']";
	WebElement Country = driver.findElement(By.xpath(countri));
	return Country;
}

public boolean signUp(String FirstName, String LastName, String EmailAddress, String Password, String JoiningDate
		,String Country, String Degree,String FavCheese) {
try {
//Signup page loads when signup button is clicked
BrowserFactory.waitFor(60).until(ExpectedConditions.visibilityOf(signup));
signup.click();
Reporting.test.log(LogStatus.INFO, "Clicked on Sign Up Link");
System.out.println("Clicked on Sign Up Link");
BrowserFactory.waitFor(60).until(ExpectedConditions.visibilityOf(validateSignUp));
String SignUpPageHeader = validateSignUp.getText();
Assert.assertEquals(SignUpPageHeader, "Create your account");
Reporting.test.log(LogStatus.PASS, "Sign Up Page is displayed");
//User is able to sign up on entering valid information; Upon signup user is taken to event dashboard
firstName.sendKeys(FirstName);
Reporting.test.log(LogStatus.INFO, "Entered FirstName : "+FirstName);
lastName.sendKeys(LastName);
Reporting.test.log(LogStatus.INFO, "Entered LastName : "+LastName);
email.sendKeys(EmailAddress);
Reporting.test.log(LogStatus.INFO, "Entered EmailAddress : "+EmailAddress);
password.sendKeys(Password);
Reporting.test.log(LogStatus.INFO, "Entered Password : "+Password);
confirmPassword.sendKeys(Password);
Reporting.test.log(LogStatus.INFO, "Entered Confirm Password : "+Password);
AgreeCheckBox.click();
Reporting.test.log(LogStatus.INFO, "Clicked on I agree to Unibuddy�s Privacy Policy checkbox");
SignUpContinue.click();
Reporting.test.log(LogStatus.INFO, "Clicked on Sign up button");
Assert.assertEquals(true,FinallyFewSteps.isDisplayed());
String SignedUpUsername = verifyLoggedInUser.getText();
Assert.assertEquals(SignedUpUsername, FirstName+" "+LastName);
Reporting.test.log(LogStatus.PASS, "Verified next page after entering basic sign up details");
getJoiningDateLocator(JoiningDate).click();
Reporting.test.log(LogStatus.INFO, "Selected Joining Date");
enterCountry.sendKeys(Country);
Reporting.test.log(LogStatus.INFO, "Entered Country : "+Country);
getCountry(Country).click();
Reporting.test.log(LogStatus.INFO, "Selected Country as "+Country+" from the List");
Select s = new Select(selectDegree);
s.selectByVisibleText(Degree);
Reporting.test.log(LogStatus.INFO, "Selected Degree : "+Degree);
dontKnow.click();
Reporting.test.log(LogStatus.INFO, "Clicked on Dont Know Link");
agreeCheckboxMarketting.click();
Reporting.test.log(LogStatus.INFO, "Clicked on I Agree to Markettting checkbox");
continueBtn.click();
Reporting.test.log(LogStatus.INFO, "Clicked on Continue Button");
Assert.assertEquals(true,myFirstEvent.isDisplayed());
Reporting.test.log(LogStatus.PASS, "Event Created Successfully");
return true;
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
return false;
}
}
 
}
