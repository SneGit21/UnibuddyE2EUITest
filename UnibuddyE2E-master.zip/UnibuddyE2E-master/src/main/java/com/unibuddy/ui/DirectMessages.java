package com.unibuddy.ui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class DirectMessages {
	WebDriver driver;
	 
	public DirectMessages(WebDriver driver){
	this.driver=driver;
	}


@FindBy(how=How.XPATH,using="//button[contains(text(),'Direct Message')]//*[local-name()='svg']")
@CacheLookup
WebElement directMsg;
@FindBy(how=How.XPATH,using="//p[contains(text(),'Select a buddy to begin a conversation.')]")
@CacheLookup
WebElement directMsgPopUp;
@FindBy(how=How.XPATH,using="//a[1]//div[1]//div[1]//div[2]//div[1]//div[1]//span[1]//span[1]")
@CacheLookup
WebElement selectFirstUser;
@FindBy(how=How.XPATH,using="//textarea[@id='chat-input']")
@CacheLookup
WebElement selectMsgToUser;
@FindBy(how=How.XPATH,using="//span[contains(text(),'")
@CacheLookup
WebElement verifyMsgToUser1;
@FindBy(how=How.XPATH,using="')]")
@CacheLookup
WebElement verifyMsgToUser2;

	public void loginWordPress(String use, String pass) {
	try {
	} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	}
	 
}
