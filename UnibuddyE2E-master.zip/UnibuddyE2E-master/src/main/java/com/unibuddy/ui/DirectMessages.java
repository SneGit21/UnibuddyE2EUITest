package com.unibuddy.ui;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.unibuddy.framework.BrowserFactory;
import com.unibuddy.framework.Reporting;

public class DirectMessages {
	WebDriver driver;

	public DirectMessages(WebDriver driver){
		this.driver=driver;
	}


	@FindBy(how=How.XPATH,using="//button[contains(text(),'Direct Message')]//*[local-name()='svg']")
	@CacheLookup
	WebElement directMsg;
	@FindBy(how=How.XPATH,using="//p[contains(text(),'Select a buddy to begin a conversation.')]")
	@CacheLookup
	WebElement directMsgPopUp;
	@FindBy(how=How.XPATH,using="//a[1]//div[1]//div[1]//div[2]//div[1]//div[1]//span[1]//span[1]")
	////span[contains(text(),'Lisa')]
	@CacheLookup
	WebElement selectFirstUser;
	@FindBy(how=How.XPATH,using="//textarea[@id='chat-input']")
	@CacheLookup
	WebElement enterMsgToUser;
	@FindBy(how=How.XPATH,using="//button[.='Send']")
	@CacheLookup
	WebElement sendMsg;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'")
	@CacheLookup
	WebElement verifyMsgToUser1;
	@FindBy(how=How.XPATH,using="')]")
	@CacheLookup
	WebElement verifyMsgToUser2;
	public WebElement getMsg(String Message){
		System.out.println("Message inside getMSg : "+Message);
		String msg = "//span[@class='_3npN'][contains(text(),'"+Message+"']";
		System.out.println("Xpath : "+msg);
		WebElement message = driver.findElement(By.xpath(msg));
		return message;
	}
	public boolean sendDirectMsgToUser(String User, String Message) {
		try {
			directMsg.click();
			System.out.println("Clicked on Direct Messages + icon");
			Reporting.test.log(LogStatus.INFO, "Clicked on Direct Messages + icon");
			BrowserFactory.waitFor(10).until(ExpectedConditions.visibilityOf(directMsgPopUp));
			Assert.assertEquals(true, directMsgPopUp.isDisplayed());
			System.out.println("Direct Messages pop-up is displayed");
			Reporting.test.log(LogStatus.PASS, "Direct Messages pop-up is displayed");
			BrowserFactory.waitFor(10).until(ExpectedConditions.visibilityOf(selectFirstUser));
			selectFirstUser.click();
			System.out.println("Selected First User from the list");
			Reporting.test.log(LogStatus.INFO, "Selected First User from the list");
			BrowserFactory.waitFor(10).until(ExpectedConditions.elementToBeClickable(enterMsgToUser));
			enterMsgToUser.sendKeys(Message);
			System.out.println("Entered Message "+Message+" to the chat");
			Reporting.test.log(LogStatus.INFO, "Entered Message "+Message+" to the chat");
			BrowserFactory.stateElementExceptionHandler(sendMsg);
			BrowserFactory.waitFor(5).until(ExpectedConditions.elementToBeClickable(sendMsg));
			sendMsg.click();
			System.out.println("Clicked on Send Button");
			Reporting.test.log(LogStatus.INFO, "Clicked on Send Button");
			System.out.println("Given Message "+Message+" sent successfully");
			Reporting.test.log(LogStatus.PASS, "Given Message "+Message+" sent successfully");
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

}
