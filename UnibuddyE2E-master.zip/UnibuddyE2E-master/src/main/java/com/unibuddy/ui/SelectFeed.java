package com.unibuddy.ui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
 
public class SelectFeed {
 
WebDriver driver;
 
public SelectFeed(WebDriver driver){
this.driver=driver;
}

@FindBy(how=How.XPATH,using="//div[text()='")
@CacheLookup
WebElement selectFeed1;
@FindBy(how=How.XPATH,using="']")
@CacheLookup
WebElement selectFeed2;
@FindBy(how=How.XPATH,using="//textarea[@id='chat-text-input']")
@CacheLookup
WebElement enterMessage;
@FindBy(how=How.XPATH,using="//button[.='Send']")
@CacheLookup
WebElement sendMsg;
@FindBy(how=How.XPATH,using="//div[contains(text(),'You said')]/../span/span")
@CacheLookup
WebElement verifySentMsg;

public void loginWordPress(String use, String pass) {
try {
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}
 
}
