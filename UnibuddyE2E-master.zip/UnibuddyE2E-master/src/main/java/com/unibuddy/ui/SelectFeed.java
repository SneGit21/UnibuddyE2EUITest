package com.unibuddy.ui;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.relevantcodes.extentreports.LogStatus;
import com.unibuddy.framework.BrowserFactory;
import com.unibuddy.framework.Reporting;

public class SelectFeed {

	WebDriver driver;

	public SelectFeed(WebDriver driver){
		this.driver=driver;
	}

	@FindBy(how=How.XPATH,using="//div[text()='")
	@CacheLookup
	WebElement selectFeed1;
	@FindBy(how=How.XPATH,using="']")
	@CacheLookup
	WebElement selectFeed2;
	@FindBy(how=How.XPATH,using="//textarea[@id='chat-text-input']")
	@CacheLookup
	WebElement enterMessage;
	@FindBy(how=How.XPATH,using="//button[.='Send']")
	@CacheLookup
	WebElement sendMsg;
	@FindBy(how=How.XPATH,using="//div[contains(text(),'You said')]/../span/span")
	@CacheLookup
	WebElement verifySentMsg;
	public WebElement getFeed(String feed){
		String feedName = "//div[text()='"+feed+"']";
		WebElement feedele = driver.findElement(By.xpath(feedName));
		BrowserFactory.waitFor(300).until(ExpectedConditions.visibilityOf(feedele));
		return feedele;
	}

	public boolean selectFeed(String feedName, String Message) {
		try {
			getFeed(feedName).click();
			System.out.println("Clicked on a Feed : "+feedName);
			Reporting.test.log(LogStatus.INFO, "Clicked on a Feed : "+feedName);

			Thread.sleep(3000);
			//BrowserFactory.stateElementExceptionHandler(enterMessage);
			BrowserFactory.waitFor(10).until(ExpectedConditions.elementToBeClickable(enterMessage));
			enterMessage.sendKeys(Message);
			System.out.println("Entered Message to chat : "+Message);
			Reporting.test.log(LogStatus.INFO, "Entered Message to chat : "+Message);
			BrowserFactory.waitFor(10).until(ExpectedConditions.elementToBeClickable(sendMsg));
			sendMsg.click();
			System.out.println("Clicked on Send button");
			Reporting.test.log(LogStatus.INFO, "Clicked on Send button");
			String sentMsg = verifySentMsg.getText();
			BrowserFactory.waitFor(20).until(ExpectedConditions.visibilityOf(verifySentMsg));
			Assert.assertEquals(sentMsg, Message);
			System.out.println("Given message sent successfully to chat");
			Reporting.test.log(LogStatus.PASS, "Given message sent successfully to chat");
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

}
