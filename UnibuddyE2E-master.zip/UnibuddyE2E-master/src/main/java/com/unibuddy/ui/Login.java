package com.unibuddy.ui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
 
public class Login {
 
WebDriver driver;
 
public Login(WebDriver driver){
this.driver=driver;
}

@FindBy(how=How.XPATH,using="//a[contains(text(),'Log in')]")
@CacheLookup
WebElement verifyLogInBtn;
@FindBy(how=How.XPATH,using="//h1[contains(text(),'Login')]")
@CacheLookup
WebElement verifyLoginScreen;
@FindBy(how=How.XPATH,using="//button[@id='login']")
@CacheLookup
WebElement loginButton;
@FindBy(how=How.XPATH,using="//span[@class='sc-AxhCb eilNNX']//span")
@CacheLookup
WebElement verifyLoggedInUser;
@FindBy(how=How.XPATH,using="//input[@id='email']")
@CacheLookup
WebElement email;
@FindBy(how=How.XPATH,using="//input[@id='password']")
@CacheLookup
WebElement password;


public void loginWordPress(String use, String pass) {
try {
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}
 
}
