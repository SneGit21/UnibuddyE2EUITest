package com.unibuddy.ui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.unibuddy.framework.Reporting;

public class Login {

	WebDriver driver;

	public Login(WebDriver driver){
		this.driver=driver;
	}

	@FindBy(how=How.XPATH,using="//a[contains(text(),'Log in')]")
	@CacheLookup
	WebElement verifyLogInBtn;
	@FindBy(how=How.XPATH,using="//h1[contains(text(),'Login')]")
	@CacheLookup
	WebElement verifyLoginScreen;
	@FindBy(how=How.XPATH,using="//button[@id='login']")
	@CacheLookup
	WebElement loginButton;
	@FindBy(how=How.XPATH,using="//span[@class='sc-AxhCb eilNNX']//span")
	@CacheLookup
	WebElement verifyLoggedInUser;
	@FindBy(how=How.XPATH,using="//input[@id='email']")
	@CacheLookup
	WebElement email;
	@FindBy(how=How.XPATH,using="//input[@id='password']")
	@CacheLookup
	WebElement password;


	public boolean login(String FirstName, String LastName, String Emailaddress, String Password) {
		try {
			verifyLogInBtn.click();
			Reporting.test.log(LogStatus.INFO, "Clicked on Log in link");
			email.sendKeys(Emailaddress);
			Reporting.test.log(LogStatus.INFO, "Entered Email Address : "+Emailaddress);
			password.sendKeys(Password);
			Reporting.test.log(LogStatus.INFO, "Entered Password : "+Password);
			loginButton.click();
			Reporting.test.log(LogStatus.INFO, "Clicked on Login Button");
			String loggedInUser = verifyLoggedInUser.getText();
			Assert.assertEquals(loggedInUser, FirstName+" "+LastName);
			Reporting.test.log(LogStatus.PASS, "Correct User is Logged In");
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

}
